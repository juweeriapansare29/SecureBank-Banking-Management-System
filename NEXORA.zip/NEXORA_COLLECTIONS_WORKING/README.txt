NEXORA – COLLECTION BUTTONS UPDATE

Open index.html in a browser. The category chips, department Explore buttons, banner Shop buttons, and scroll-showcase Explore button now filter the matching collection and smoothly move to the product catalogue.

This remains the local demo build. Firebase multi-device sync and live payment processing are not included.
